$(document).ready(function(){
//	固定目录和回到顶部特效
	$(document).scroll(function(){
		console.log($(document).scrollTop());
		if($(document).scrollTop()<300){
			$('#mulu').hide();
			$('#return').hide();
		}
		if($(document).scrollTop()>300){
			$('#mulu').show();
			$('#return').show();
		}
		if($(document).scrollTop()>4000){
			$('#mulu').hide();
		}
		if($(document).scrollTop()<4000 && $(document).scrollTop()>300){
			$('#mulu').show();
		}
	})
	$(function() {
		var originalCur = $("#nav_main li.current");
		$("#nav_main li").mousemove(function(){
			$("#nav_main li").removeClass("current");	
			$(this).addClass("current");		
			$(this).children(".lm").show().animate({left : 15,top : 40}, "fast");
		});
		$("#nav_main li").mouseleave(function(){
			$(this).removeClass("current");	
			$(this).children(".lm").stop(true,true).animate({left:0,top:0},100,function(){
				$(this).hide();
			});
			originalCur.addClass("current");
		});
	});
});
